# 🍽️ Restaurant Menu System

Full-stack restaurant menu with admin panel.

## Setup
1. `npm install`
2. `cp .env.example .env` (update MongoDB URI)
3. `npm run seed`
4. `npm run dev` (backend)
5. `cd frontend && npm install && npm start`

Admin: admin/restaurant123
const express = require('express');
const { body, validationResult } = require('express-validator');
const MenuItem = require('../models/MenuItem');
const Category = require('../models/Category');
const auth = require('../middleware/auth');
const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const menuItems = await MenuItem.find().populate('category', 'name description order').sort({ order: 1, name: 1 });

    const groupedMenu = {};
    menuItems.forEach(item => {
      const categoryName = item.category.name;
      if (!groupedMenu[categoryName]) {
        groupedMenu[categoryName] = { category: item.category, items: [] };
      }
      groupedMenu[categoryName].items.push(item);
    });

    const menuArray = Object.values(groupedMenu).sort((a, b) => (a.category.order || 0) - (b.category.order || 0));
    res.json({ success: true, data: menuArray, totalItems: menuItems.length });
  } catch (error) {
    res.status(500).json({ message: 'Error fetching menu' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const menuItem = await MenuItem.findById(req.params.id).populate('category', 'name description');
    if (!menuItem) return res.status(404).json({ message: 'Menu item not found' });
    res.json({ success: true, data: menuItem });
  } catch (error) {
    res.status(500).json({ message: 'Error fetching menu item' });
  }
});

router.post('/', auth, [
  body('name').trim().isLength({ min: 1, max: 100 }).withMessage('Name must be 1-100 characters'),
  body('description').trim().isLength({ min: 1, max: 500 }).withMessage('Description must be 1-500 characters'),
  body('price').isFloat({ min: 0 }).withMessage('Price must be positive'),
  body('category').isMongoId().withMessage('Valid category required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ message: 'Validation failed', errors: errors.array() });
    }

    const category = await Category.findById(req.body.category);
    if (!category) return res.status(400).json({ message: 'Category not found' });

    const menuItem = new MenuItem(req.body);
    await menuItem.save();
    await menuItem.populate('category', 'name description');

    res.status(201).json({ success: true, data: menuItem });
  } catch (error) {
    res.status(500).json({ message: 'Error creating menu item' });
  }
});

router.put('/:id', auth, async (req, res) => {
  try {
    const menuItem = await MenuItem.findByIdAndUpdate(req.params.id, req.body, { new: true })
      .populate('category', 'name description');
    if (!menuItem) return res.status(404).json({ message: 'Menu item not found' });
    res.json({ success: true, data: menuItem });
  } catch (error) {
    res.status(500).json({ message: 'Error updating menu item' });
  }
});

router.delete('/:id', auth, async (req, res) => {
  try {
    const menuItem = await MenuItem.findByIdAndDelete(req.params.id);
    if (!menuItem) return res.status(404).json({ message: 'Menu item not found' });
    res.json({ success: true, message: 'Menu item deleted' });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting menu item' });
  }
});

router.patch('/:id/availability', auth, async (req, res) => {
  try {
    const menuItem = await MenuItem.findById(req.params.id);
    if (!menuItem) return res.status(404).json({ message: 'Menu item not found' });

    menuItem.isAvailable = !menuItem.isAvailable;
    await menuItem.save();

    res.json({ success: true, data: { isAvailable: menuItem.isAvailable } });
  } catch (error) {
    res.status(500).json({ message: 'Error updating availability' });
  }
});

module.exports = router;
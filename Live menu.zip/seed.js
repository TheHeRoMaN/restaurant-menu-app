const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const User = require('./models/User');
const Category = require('./models/Category');
const MenuItem = require('./models/MenuItem');

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/restaurant-menu', {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('✓ MongoDB connected for seeding');
  } catch (error) {
    console.error('✗ MongoDB connection error:', error);
    process.exit(1);
  }
};

const seedData = async () => {
  try {
    console.log('🌱 Starting database seeding...');

    await User.deleteMany({});
    await MenuItem.deleteMany({});
    await Category.deleteMany({});

    const adminUser = new User({
      username: process.env.ADMIN_USERNAME || 'admin',
      password: process.env.ADMIN_PASSWORD || 'restaurant123',
      role: 'admin'
    });
    await adminUser.save();
    console.log('✓ Admin user created');

    const categories = [
      { name: 'Appetizers', description: 'Start your meal with our delicious appetizers', order: 1 },
      { name: 'Main Courses', description: 'Our signature main dishes', order: 2 },
      { name: 'Desserts', description: 'Sweet endings to your meal', order: 3 },
      { name: 'Beverages', description: 'Refreshing drinks and beverages', order: 4 }
    ];

    const createdCategories = await Category.insertMany(categories);
    console.log('✓ Categories created');

    const [appetizers, mains, desserts, beverages] = createdCategories;

    const menuItems = [
      {
        name: 'Bruschetta Trio',
        description: 'Three slices of toasted ciabatta topped with fresh tomatoes, basil, and mozzarella',
        price: 12.99,
        category: appetizers._id,
        image: 'https://images.unsplash.com/photo-1572695157366-5e585ab2b69f?w=400&h=300&fit=crop',
        preparationTime: 10,
        ingredients: ['Ciabatta bread', 'Tomatoes', 'Fresh basil', 'Mozzarella'],
        allergens: ['gluten', 'dairy']
      },
      {
        name: 'Ribeye Steak',
        description: '12oz premium ribeye steak grilled to perfection with garlic mashed potatoes',
        price: 32.99,
        category: mains._id,
        image: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=400&h=300&fit=crop',
        preparationTime: 25,
        ingredients: ['Ribeye steak', 'Potatoes', 'Garlic', 'Butter'],
        allergens: ['dairy']
      },
      {
        name: 'Tiramisu',
        description: 'Classic Italian dessert with coffee-soaked ladyfingers and mascarpone',
        price: 8.99,
        category: desserts._id,
        image: 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=400&h=300&fit=crop',
        preparationTime: 5,
        allergens: ['gluten', 'dairy', 'eggs']
      },
      {
        name: 'Fresh Orange Juice',
        description: 'Freshly squeezed orange juice served chilled',
        price: 4.99,
        category: beverages._id,
        image: 'https://images.unsplash.com/photo-1465101046530-73398c7f28ca?w=400&h=300&fit=crop',
        preparationTime: 3
      }
    ];

    await MenuItem.insertMany(menuItems);
    console.log('✓ Menu items created');

    console.log('\n🎉 Database seeding completed!');
    console.log('\n📝 Login credentials:');
    console.log(`   Username: ${process.env.ADMIN_USERNAME || 'admin'}`);
    console.log(`   Password: ${process.env.ADMIN_PASSWORD || 'restaurant123'}`);

  } catch (error) {
    console.error('✗ Error seeding database:', error);
  }
};

const runSeed = async () => {
  await connectDB();
  await seedData();
  mongoose.disconnect();
  process.exit(0);
};

runSeed();